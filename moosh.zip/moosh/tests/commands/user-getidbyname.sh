#!/bin/bash
# this command has been deprecated
exit 0