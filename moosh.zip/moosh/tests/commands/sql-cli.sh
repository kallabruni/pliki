#!/bin/bash -x
#source functions.sh
exit 0;
#install_db
#install_data
#cd $MOODLEDIR
#$MOOSHCMD sql-cli

#if $MOOSHCMD sql-cli | grep "Welcome to the MySQL monitor"; then
#  exit 0
#else
#  exit 1
#fi
