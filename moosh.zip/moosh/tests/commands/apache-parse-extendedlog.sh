#!/bin/bash
source functions.sh

# install_db
# install_data

# cd $MOODLEDIR
exit 1;