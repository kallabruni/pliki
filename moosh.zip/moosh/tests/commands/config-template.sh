#!/bin/bash

export DBNAME=
export DBUSER=
export DBPASSWORD=
export MOODLEDATA=
export MOODLEDIR=

#moodledata25 for Moodle 2.5
export SOURCEDATA=

#moodle25 for Moodle 2.5
export SOURCESQL=
